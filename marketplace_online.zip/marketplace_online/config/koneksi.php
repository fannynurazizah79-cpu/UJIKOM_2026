<?php
// Config DB
$host = "localhost";
$user = "root";
$pass = "";
$db   = "db_marketplace";

$koneksi = mysqli_connect($host, $user, $pass, $db);

if (!$koneksi) {
    die("Koneksi Database Gagal: " . mysqli_connect_error());
}

// Helper Function ID Generator VARCHAR
function generateID($prefix, $table, $primary_key) {
    global $koneksi;
    $query = "SELECT $primary_key FROM $table ORDER BY $primary_key DESC LIMIT 1";
    $result = mysqli_query($koneksi, $query);
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $last_id = $row[$primary_key];
        $num = (int) filter_var($last_id, FILTER_SANITIZE_NUMBER_INT);
        $new_num = $num + 1;
        return $prefix . str_pad($new_num, 3, "0", STR_PAD_LEFT);
    }
    return $prefix . "001";
}
?>