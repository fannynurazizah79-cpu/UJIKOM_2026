<?php
include 'includes/header.php';

$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';
$kategori_filter = isset($_GET['kategori']) ? mysqli_real_escape_string($koneksi, $_GET['kategori']) : '';

$query = "SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori = k.id_kategori WHERE 1=1";
if ($search != '') {
    $query .= " AND p.nama_produk LIKE '%$search%'";
}
if ($kategori_filter != '') {
    $query .= " AND p.id_kategori = '$kategori_filter'";
}
$query .= " ORDER BY p.id_produk DESC";
$result_produk = mysqli_query($koneksi, $query);

$query_kat = "SELECT * FROM kategori";
$result_kat = mysqli_query($koneksi, $query_kat);
?>

<div class="hero-banner text-center mb-4">
    <div class="container">
        <h1 class="fw-bold">Selamat Datang di Nusantara Store</h1>
        <p class="lead">Temukan Produk Terbaik Dengan Harga Terjangkau</p>
    </div>
</div>

<div class="container my-4">
    <!-- Filter & Search Form -->
    <div class="card p-3 mb-4 shadow-sm">
        <form method="GET" action="index.php" class="row g-3">
            <div class="col-md-5">
                <input type="text" name="search" class="form-control" placeholder="Cari nama produk..." value="<?= htmlspecialchars($search); ?>">
            </div>
            <div class="col-md-4">
                <select name="kategori" class="form-select">
                    <option value="">-- Semua Kategori --</option>
                    <?php while($kat = mysqli_fetch_assoc($result_kat)): ?>
                        <option value="<?= $kat['id_kategori']; ?>" <?= $kategori_filter == $kat['id_kategori'] ? 'selected' : ''; ?>>
                            <?= $kat['nama_kategori']; ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="col-md-3 d-grid">
                <button type="submit" class="btn btn-primary"><i class="bi bi-search"></i> Cari / Filter</button>
            </div>
        </form>
    </div>

    <!-- Katalog Produk -->
    <h3 class="mb-3 border-bottom pb-2">Katalog Produk</h3>
    <div class="row">
        <?php if(mysqli_num_rows($result_produk) > 0): ?>
            <?php while($p = mysqli_fetch_assoc($result_produk)): ?>
                <div class="col-md-4 col-sm-6 mb-4">
                    <div class="card h-100 card-product shadow-sm">
                        <img src="assets/images/<?= $p['foto']; ?>" class="card-img-top" alt="<?= $p['nama_produk']; ?>" style="height: 200px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <span class="badge bg-secondary mb-2 w-auto me-auto"><?= $p['nama_kategori']; ?></span>
                            <h5 class="card-title fw-bold"><?= $p['nama_produk']; ?></h5>
                            <p class="text-danger fw-bold fs-5 mb-1">Rp <?= number_format($p['harga'], 0, ',', '.'); ?></p>
                            <p class="text-muted mb-3"><small>Stok Tersedia: <?= $p['stok']; ?></small></p>
                            <a href="detail_produk.php?id=<?= $p['id_produk']; ?>" class="btn btn-outline-primary mt-auto w-100"><i class="bi bi-eye"></i> Lihat Detail</a>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div class="col-12">
                <div class="alert alert-warning text-center py-4">Produk tidak ditemukan.</div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
