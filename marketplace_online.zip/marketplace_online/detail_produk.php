<?php
include 'includes/header.php';

if (!isset($_GET['id'])) {
    header("Location: index.php");
    exit();
}

$id_produk = mysqli_real_escape_string($koneksi, $_GET['id']);
$query = "SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori = k.id_kategori WHERE p.id_produk = '$id_produk'";
$result = mysqli_query($koneksi, $query);
$produk = mysqli_fetch_assoc($result);

if (!$produk) {
    echo "<div class='container my-5'><div class='alert alert-danger'>Produk tidak ditemukan!</div></div>";
    include 'includes/footer.php';
    exit();
}

$message = "";
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['pesan'])) {
    $nama_pembeli = mysqli_real_escape_string($koneksi, $_POST['nama_pembeli']);
    $no_hp        = mysqli_real_escape_string($koneksi, $_POST['no_hp']);
    $jumlah       = (int) $_POST['jumlah'];

    if ($jumlah <= 0) {
        $message = "<div class='alert alert-danger'>Jumlah pesanan minimal 1!</div>";
    } elseif ($jumlah > $produk['stok']) {
        $message = "<div class='alert alert-danger'>Stok tidak mencukupi!</div>";
    } else {
        $id_pesanan  = 'ORD-' . date('Ymd') . '-' . rand(100, 999);
        $total_harga = $jumlah * $produk['harga'];

        // Transaction insert order + update stok
        mysqli_begin_transaction($koneksi);
        $q1 = "INSERT INTO pesanan (id_pesanan, nama_pembeli, no_hp, id_produk, jumlah, total_harga) VALUES ('$id_pesanan', '$nama_pembeli', '$no_hp', '$id_produk', $jumlah, $total_harga)";
        $q2 = "UPDATE produk SET stok = stok - $jumlah WHERE id_produk = '$id_produk'";

        if (mysqli_query($koneksi, $q1) && mysqli_query($koneksi, $q2)) {
            mysqli_commit($koneksi);
            $message = "<div class='alert alert-success'>Pemesanan Berhasil! ID Pesanan Anda: <strong>$id_pesanan</strong>.</div>";
            // Refresh stok tampilan
            $produk['stok'] -= $jumlah;
        } else {
            mysqli_rollback($koneksi);
            $message = "<div class='alert alert-danger'>Pemesanan gagal diproses. Silahkan coba lagi.</div>";
        }
    }
}
?>

<div class="container my-5">
    <a href="index.php" class="btn btn-secondary mb-3"><i class="bi bi-arrow-left"></i> Kembali ke Katalog</a>
    <?= $message; ?>
    <div class="row">
        <div class="col-md-6 mb-4">
            <div class="card shadow-sm p-2">
                <img src="assets/images/<?= $produk['foto']; ?>" class="img-fluid rounded" alt="<?= $produk['nama_produk']; ?>" style="max-height: 400px; object-fit: cover; width:100%;">
            </div>
        </div>
        <div class="col-md-6">
            <span class="badge bg-primary mb-2"><?= $produk['nama_kategori']; ?></span>
            <h2 class="fw-bold"><?= $produk['nama_produk']; ?></h2>
            <h3 class="text-danger fw-bold my-3">Rp <?= number_format($produk['harga'], 0, ',', '.'); ?></h3>
            <p><strong>Sisa Stok:</strong> <?= $produk['stok']; ?> unit</p>
            <div class="mb-4">
                <h5 class="fw-bold">Deskripsi Produk:</h5>
                <p class="text-muted"><?= nl2br(htmlspecialchars($produk['deskripsi'])); ?></p>
            </div>

            <!-- Form Pemesanan -->
            <div class="card border-primary shadow-sm">
                <div class="card-header bg-primary text-white font-weight-bold">
                    <i class="bi bi-cart-plus"></i> Form Pemesanan Produk
                </div>
                <div class="card-body">
                    <?php if($produk['stok'] > 0): ?>
                    <form method="POST" action="">
                        <div class="mb-3">
                            <label class="form-label">Nama Lengkap Pembeli</label>
                            <input type="text" name="nama_pembeli" class="form-control" required placeholder="Contoh: Ahmad Subagja">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Nomor WhatsApp / HP</label>
                            <input type="text" name="no_hp" class="form-control" required placeholder="Contoh: 081234567890">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Jumlah Pesanan</label>
                            <input type="number" name="jumlah" class="form-control" value="1" min="1" max="<?= $produk['stok']; ?>" required>
                        </div>
                        <button type="submit" name="pesan" class="btn btn-success w-100 fw-bold"><i class="bi bi-bag-check"></i> Pesan Sekarang</button>
                    </form>
                    <?php else: ?>
                        <div class="alert alert-warning mb-0">Maaf, Stok Produk Ini Sedang Habis.</div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
