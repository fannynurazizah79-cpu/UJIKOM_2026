<?php
session_start();
include '../config/koneksi.php';

$error = "";
if (isset($_POST['login'])) {
    $email    = mysqli_real_escape_string($koneksi, $_POST['email']);
    $password = $_POST['password'];

    $query  = "SELECT * FROM admin WHERE email = '$email'";
    $result = mysqli_query($koneksi, $query);

    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        // Cek password hash atau plain jika awal
        if (password_verify($password, $row['password']) || $password === 'admin123') {
            $_SESSION['admin_logged'] = true;
            $_SESSION['admin_id']     = $row['id_admin'];
            $_SESSION['admin_nama']   = $row['nama_admin'];
            header("Location: dashboard.php");
            exit();
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Email tidak terdaftar!";
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin - Marketplace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body { background: #eef2f5; display: flex; align-items: center; justify-content: center; height: 100vh; }
        .login-card { width: 100%; max-width: 400px; border-radius: 10px; }
    </style>
</head>
<body>
<div class="card shadow login-card p-4">
    <h4 class="text-center fw-bold mb-3">LOGIN ADMIN</h4>
    <?php if($error): ?>
        <div class="alert alert-danger py-2"><?= $error; ?></div>
    <?php endif; ?>
    <form method="POST" action="">
        <div class="mb-3">
            <label class="form-label">Email Admin</label>
            <input type="email" name="email" class="form-control" required value="admin@marketplace.com">
        </div>
        <div class="mb-3">
            <label class="form-label">Password</label>
            <input type="password" name="password" class="form-control" required placeholder="Default: admin123">
        </div>
        <button type="submit" name="login" class="btn btn-primary w-100 fw-bold">Login</button>
        <a href="../index.php" class="btn btn-link w-100 text-center mt-2">Kembali ke Beranda</a>
    </form>
</div>
</body>
</html>
