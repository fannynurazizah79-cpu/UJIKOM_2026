<?php
include 'admin_header.php';

// Hapus Produk
if (isset($_GET['hapus'])) {
    $id_hapus = mysqli_real_escape_string($koneksi, $_GET['hapus']);
    mysqli_query($koneksi, "DELETE FROM produk WHERE id_produk = '$id_hapus'");
    header("Location: produk.php");
    exit();
}

$query = "SELECT p.*, k.nama_kategori FROM produk p JOIN kategori k ON p.id_kategori = k.id_kategori ORDER BY p.id_produk DESC";
$produk_list = mysqli_query($koneksi, $query);
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2 class="fw-bold">Manajemen Produk</h2>
    <a href="produk_form.php" class="btn btn-primary"><i class="bi bi-plus-lg"></i> Tambah Produk Baru</a>
</div>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th>Foto</th>
                        <th>ID Produk</th>
                        <th>Nama Produk</th>
                        <th>Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while($p = mysqli_fetch_assoc($produk_list)): ?>
                    <tr>
                        <td>
                            <img src="../assets/images/<?= $p['foto']; ?>" style="width: 50px; height: 50px; object-fit: cover;" class="rounded">
                        </td>
                        <td><code><?= $p['id_produk']; ?></code></td>
                        <td class="fw-bold"><?= $p['nama_produk']; ?></td>
                        <td><span class="badge bg-info text-dark"><?= $p['nama_kategori']; ?></span></td>
                        <td>Rp <?= number_format($p['harga'], 0, ',', '.'); ?></td>
                        <td>
                            <span class="badge bg-<?= $p['stok'] > 5 ? 'success' : 'danger'; ?>"><?= $p['stok']; ?></span>
                        </td>
                        <td>
                            <a href="produk_form.php?id=<?= $p['id_produk']; ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i> Edit</a>
                            <a href="produk.php?hapus=<?= $p['id_produk']; ?>" onclick="return confirm('Yakin hapus produk ini?')" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i> Hapus</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'admin_footer.php'; ?>
