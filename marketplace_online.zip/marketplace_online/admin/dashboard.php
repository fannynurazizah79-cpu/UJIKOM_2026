<?php
include 'admin_header.php';

$total_produk = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM produk"))['total'];
$total_kategori = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM kategori"))['total'];
$total_pesanan = mysqli_fetch_assoc(mysqli_query($koneksi, "SELECT COUNT(*) as total FROM pesanan"))['total'];
?>

<h2 class="fw-bold mb-4">Dashboard Admin</h2>

<div class="row">
    <div class="col-md-4 mb-3">
        <div class="card bg-primary text-white shadow-sm p-3">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6>Total Produk</h6>
                    <h2><?= $total_produk; ?></h2>
                </div>
                <i class="bi bi-box-seam fs-1"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card bg-success text-white shadow-sm p-3">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6>Total Kategori</h6>
                    <h2><?= $total_kategori; ?></h2>
                </div>
                <i class="bi bi-tags fs-1"></i>
            </div>
        </div>
    </div>
    <div class="col-md-4 mb-3">
        <div class="card bg-warning text-dark shadow-sm p-3">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h6>Total Pesanan</h6>
                    <h2><?= $total_pesanan; ?></h2>
                </div>
                <i class="bi bi-cart-check fs-1"></i>
            </div>
        </div>
    </div>
</div>

<div class="card shadow-sm mt-4">
    <div class="card-header bg-white font-weight-bold">
        Selamat Datang, <strong><?= $_SESSION['admin_nama']; ?></strong>
    </div>
    <div class="card-body">
        <p>Anda berada di Control Panel Admin Marketplace Online. Gunakan menu di sebelah kiri untuk mengelola data kategori, produk, serta melihat riwayat pesanan dari pembeli.</p>
    </div>
</div>

<?php include 'admin_footer.php'; ?>
