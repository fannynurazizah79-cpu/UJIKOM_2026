<?php
session_start();
if (!isset($_SESSION['admin_logged'])) {
    header("Location: login.php");
    exit();
}
include '../config/koneksi.php';
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Marketplace</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">
    <style>
        body { background-color: #f4f6f9; }
        .sidebar { min-height: 100vh; background: #343a40; color: white; }
        .sidebar a { color: #c2c7d0; text-decoration: none; display: block; padding: 10px 15px; }
        .sidebar a:hover, .sidebar a.active { background: #0d6efd; color: white; border-radius: 4px; }
    </style>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-2 sidebar p-3 d-none d-md-block">
            <h5 class="text-center fw-bold py-2 border-bottom">Admin Panel</h5>
            <div class="mt-3">
                <a href="dashboard.php"><i class="bi bi-speedometer2"></i> Dashboard</a>
                <a href="kategori.php"><i class="bi bi-tags"></i> Kategori Produk</a>
                <a href="produk.php"><i class="bi bi-box-seam"></i> Manajemen Produk</a>
                <a href="pesanan.php"><i class="bi bi-cart-check"></i> Daftar Pesanan</a>
                <hr>
                <a href="logout.php" class="text-danger"><i class="bi bi-box-arrow-right"></i> Logout</a>
            </div>
        </div>
        <!-- Main Content -->
        <div class="col-md-10 p-4">
