<?php
include 'admin_header.php';

$id_produk   = '';
$id_kategori = '';
$nama_produk = '';
$deskripsi   = '';
$harga       = '';
$stok        = 0;
$foto        = 'default.jpg';
$is_edit     = false;

if (isset($_GET['id'])) {
    $is_edit   = true;
    $id_target = mysqli_real_escape_string($koneksi, $_GET['id']);
    $res       = mysqli_query($koneksi, "SELECT * FROM produk WHERE id_produk = '$id_target'");
    $data      = mysqli_fetch_assoc($res);
    if ($data) {
        $id_produk   = $data['id_produk'];
        $id_kategori = $data['id_kategori'];
        $nama_produk = $data['nama_produk'];
        $deskripsi   = $data['deskripsi'];
        $harga       = $data['harga'];
        $stok        = (int)$data['stok'];
        $foto        = $data['foto'];
    }
}

// Proses Simpan / Update
if (isset($_POST['simpan_produk'])) {
    $id_p      = mysqli_real_escape_string($koneksi, $_POST['id_produk']);
    $id_kat    = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $nama      = mysqli_real_escape_string($koneksi, $_POST['nama_produk']);
    $desk      = mysqli_real_escape_string($koneksi, $_POST['deskripsi']);
    $hrg       = (float) $_POST['harga'];
    $stk       = (int) $_POST['stok'];
    $mode_edit = $_POST['is_edit_mode'];
    $foto_lama = $_POST['foto_lama'];

    // Upload Foto
    $foto_name = $foto_lama; 
    if (isset($_FILES['foto']['name']) && $_FILES['foto']['name'] != '') {
        $filename  = $_FILES['foto']['name'];
        $ext       = pathinfo($filename, PATHINFO_EXTENSION);
        $foto_name = time() . '_' . rand(100,999) . '.' . $ext;
        $tmp_name  = $_FILES['foto']['tmp_name'];
        
        move_uploaded_file($tmp_name, "../assets/images/" . $foto_name);
    }

    if ($mode_edit == '1') {
        $query = "UPDATE produk SET id_kategori='$id_kat', nama_produk='$nama', deskripsi='$desk', harga=$hrg, stok=$stk, foto='$foto_name' WHERE id_produk='$id_p'";
    } else {
        $query = "INSERT INTO produk (id_produk, id_kategori, nama_produk, deskripsi, harga, stok, foto) VALUES ('$id_p', '$id_kat', '$nama', '$desk', $hrg, $stk, '$foto_name')";
    }

    if (mysqli_query($koneksi, $query)) {
        header("Location: produk.php");
        exit();
    } else {
        echo "<script>alert('Gagal menyimpan data: " . mysqli_error($koneksi) . "');</script>";
    }
}

$kategori_options = mysqli_query($koneksi, "SELECT * FROM kategori");
?>

<h2 class="fw-bold mb-4"><?= $is_edit ? 'Edit Produk' : 'Tambah Produk Baru'; ?></h2>

<div class="card shadow-sm">
    <div class="card-body">
        <form method="POST" action="" enctype="multipart/form-data">
            <input type="hidden" name="is_edit_mode" value="<?= $is_edit ? '1' : '0'; ?>">
            <input type="hidden" name="foto_lama" value="<?= $foto; ?>">

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">ID Produk</label>
                    <input type="text" name="id_produk" class="form-control" value="<?= htmlspecialchars($id_produk); ?>" placeholder="Misal: PRD-01" <?= $is_edit ? 'readonly' : 'required'; ?>>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Kategori</label>
                    <select name="id_kategori" class="form-select" required>
                        <option value="">-- Pilih Kategori --</option>
                        <?php while($k = mysqli_fetch_assoc($kategori_options)): ?>
                            <option value="<?= $k['id_kategori']; ?>" <?= $id_kategori == $k['id_kategori'] ? 'selected' : ''; ?>>
                                <?= $k['nama_kategori']; ?>
                            </option>
                        <?php endwhile; ?>
                    </select>
                </div>
                <div class="col-md-12 mb-3">
                    <label class="form-label">Nama Produk</label>
                    <input type="text" name="nama_produk" class="form-control" value="<?= htmlspecialchars($nama_produk); ?>" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Harga (Rp)</label>
                    <input type="number" name="harga" class="form-control" value="<?= $harga; ?>" required>
                </div>

                <!-- BAGIAN STOK & TOMBOL TAMBAH STOK -->
                <div class="col-md-6 mb-3">
                    <label class="form-label">Total Stok Produk</label>
                    <!-- READONLY HANYA AKTIF SAAT EDIT (MODE $is_edit) -->
                    <input type="number" id="stok_utama" name="stok" class="form-control mb-2" value="<?= $stok; ?>" required <?= $is_edit ? 'readonly' : ''; ?>>
                    
                    <?php if ($is_edit): ?>
                    <!-- Form Cepat Tambah Stok (Khusus Edit) -->
                    <div class="input-group">
                        <input type="number" id="input_tambah_stok" class="form-control" placeholder="Masukan jml stok baru (cth: 10)">
                        <button type="button" class="btn btn-outline-success" onclick="tambahStokOtomatis()">
                            <i class="bi bi-plus-circle"></i> + Tambah Stok
                        </button>
                    </div>
                    <small class="text-muted">Ketik jumlah barang masuk lalu klik "+ Tambah Stok".</small>
                    <?php endif; ?>
                </div>

                <div class="col-md-12 mb-3">
                    <label class="form-label">Deskripsi Produk</label>
                    <textarea name="deskripsi" class="form-control" rows="4" required><?= htmlspecialchars($deskripsi); ?></textarea>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Foto Produk</label>
                    <input type="file" name="foto" class="form-control" accept="image/*">
                    <small class="text-muted">Biarkan kosong jika tidak ingin mengubah foto.</small>
                </div>
                <div class="col-md-6 mb-3 text-center">
                    <label class="form-label d-block">Preview Foto Saat Ini</label>
                    <img src="../assets/images/<?= $foto; ?>" class="rounded border" style="max-height: 100px;">
                </div>
            </div>
            <hr>
            <button type="submit" name="simpan_produk" class="btn btn-success"><i class="bi bi-save"></i> Simpan Produk</button>
            <a href="produk.php" class="btn btn-secondary">Batal</a>
        </form>
    </div>
</div>

<!-- SCRIPT JAVASCRIPT HITUNG STOK OTOMATIS -->
<script>
function tambahStokOtomatis() {
    let stokLama = parseInt(document.getElementById('stok_utama').value) || 0;
    let stokTambah = parseInt(document.getElementById('input_tambah_stok').value) || 0;
    
    if (stokTambah <= 0) {
        alert('Masukkan jumlah tambahan stok yang valid!');
        return;
    }
    
    // Penjumlahan Otomatis
    let totalBaru = stokLama + stokTambah;
    document.getElementById('stok_utama').value = totalBaru;
    
    // Reset input penambah
    document.getElementById('input_tambah_stok').value = '';
    alert('Stok berhasil ditambahkan! Klik "Simpan Produk" untuk menyimpan ke database.');
}
</script>

<?php include 'admin_footer.php'; ?>