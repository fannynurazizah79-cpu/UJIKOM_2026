<?php
include 'admin_header.php';

// Tambah / Edit Kategori
if (isset($_POST['simpan'])) {
    $id_kategori   = mysqli_real_escape_string($koneksi, $_POST['id_kategori']);
    $nama_kategori = mysqli_real_escape_string($koneksi, $_POST['nama_kategori']);
    $is_edit       = $_POST['is_edit'];

    if ($is_edit == '1') {
        $query = "UPDATE kategori SET nama_kategori = '$nama_kategori' WHERE id_kategori = '$id_kategori'";
    } else {
        $query = "INSERT INTO kategori (id_kategori, nama_kategori) VALUES ('$id_kategori', '$nama_kategori')";
    }
    mysqli_query($koneksi, $query);
    header("Location: kategori.php");
    exit();
}

// Hapus
if (isset($_GET['hapus'])) {
    $id_hapus = mysqli_real_escape_string($koneksi, $_GET['hapus']);
    mysqli_query($koneksi, "DELETE FROM kategori WHERE id_kategori = '$id_hapus'");
    header("Location: kategori.php");
    exit();
}

$kategori_list = mysqli_query($koneksi, "SELECT * FROM kategori ORDER BY id_kategori ASC");

$edit_data = null;
if (isset($_GET['edit'])) {
    $id_edit = mysqli_real_escape_string($koneksi, $_GET['edit']);
    $res = mysqli_query($koneksi, "SELECT * FROM kategori WHERE id_kategori = '$id_edit'");
    $edit_data = mysqli_fetch_assoc($res);
}
?>

<h2 class="fw-bold mb-4">Manajemen Kategori</h2>

<div class="row">
    <div class="col-md-4 mb-4">
        <div class="card shadow-sm">
            <div class="card-header bg-primary text-white fw-bold">
                <?= $edit_data ? 'Edit Kategori' : 'Tambah Kategori'; ?>
            </div>
            <div class="card-body">
                <form method="POST" action="">
                    <input type="hidden" name="is_edit" value="<?= $edit_data ? '1' : '0'; ?>">
                    
                    <div class="mb-3">
                        <label class="form-label">ID Kategori</label>
                        <!-- Kolom ID bisa diketik manual saat tambah data baru -->
                        <input type="text" name="id_kategori" class="form-control" 
                               value="<?= $edit_data ? htmlspecialchars($edit_data['id_kategori']) : ''; ?>" 
                               placeholder="Misal: KAT-01" 
                               <?= $edit_data ? 'readonly' : 'required'; ?>>
                        <small class="text-muted">Masukkan ID Kategori secara manual.</small>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Nama Kategori</label>
                        <input type="text" name="nama_kategori" class="form-control" 
                               value="<?= $edit_data ? htmlspecialchars($edit_data['nama_kategori']) : ''; ?>" 
                               required placeholder="Misal: Fashion Collection">
                    </div>

                    <button type="submit" name="simpan" class="btn btn-success w-100">Simpan Data</button>
                    <?php if($edit_data): ?>
                        <a href="kategori.php" class="btn btn-secondary w-100 mt-2">Batal Edit</a>
                    <?php endif; ?>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-8">
        <div class="card shadow-sm">
            <div class="card-header bg-white fw-bold">Daftar Kategori</div>
            <div class="card-body p-0">
                <table class="table table-hover mb-0">
                    <thead class="table-light">
                        <tr>
                            <th>ID Kategori</th>
                            <th>Nama Kategori</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (mysqli_num_rows($kategori_list) > 0): ?>
                            <?php while($k = mysqli_fetch_assoc($kategori_list)): ?>
                            <tr>
                                <td><code><?= htmlspecialchars($k['id_kategori']); ?></code></td>
                                <td><?= htmlspecialchars($k['nama_kategori']); ?></td>
                                <td>
                                    <a href="kategori.php?edit=<?= $k['id_kategori']; ?>" class="btn btn-sm btn-warning"><i class="bi bi-pencil"></i> Edit</a>
                                    <a href="kategori.php?hapus=<?= $k['id_kategori']; ?>" onclick="return confirm('Yakin hapus kategori ini?')" class="btn btn-sm btn-danger"><i class="bi bi-trash"></i> Hapus</a>
                                </td>
                            </tr>
                            <?php endwhile; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="3" class="text-center py-3 text-muted">Belum ada data kategori. Silakan tambah di sebelah kiri.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php include 'admin_footer.php'; ?>