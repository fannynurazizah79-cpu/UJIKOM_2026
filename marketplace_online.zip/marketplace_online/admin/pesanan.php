<?php
include 'admin_header.php';

$query = "SELECT ord.*, prd.nama_produk FROM pesanan ord JOIN produk prd ON ord.id_produk = prd.id_produk ORDER BY ord.tanggal_pesan DESC";
$pesanan_list = mysqli_query($koneksi, $query);
?>

<h2 class="fw-bold mb-4">Daftar Pesanan (Order Masuk)</h2>

<div class="card shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-striped align-middle mb-0">
                <thead class="table-dark">
                    <tr>
                        <th>ID Pesanan</th>
                        <th>Tanggal Pesan</th>
                        <th>Nama Pembeli</th>
                        <th>Nomor HP</th>
                        <th>Produk</th>
                        <th>Jumlah</th>
                        <th>Total Harga</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(mysqli_num_rows($pesanan_list) > 0): ?>
                        <?php while($o = mysqli_fetch_assoc($pesanan_list)): ?>
                        <tr>
                            <td><code><?= $o['id_pesanan']; ?></code></td>
                            <td><small><?= date('d M Y H:i', strtotime($o['tanggal_pesan'])); ?></small></td>
                            <td class="fw-bold"><?= htmlspecialchars($o['nama_pembeli']); ?></td>
                            <td><?= htmlspecialchars($o['no_hp']); ?></td>
                            <td><?= htmlspecialchars($o['nama_produk']); ?></td>
                            <td><span class="badge bg-secondary"><?= $o['jumlah']; ?> pcs</span></td>
                            <td class="fw-bold text-success">Rp <?= number_format($o['total_harga'], 0, ',', '.'); ?></td>
                        </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr><td colspan="7" class="text-center py-4">Belum ada pesanan masuk.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<?php include 'admin_footer.php'; ?>
